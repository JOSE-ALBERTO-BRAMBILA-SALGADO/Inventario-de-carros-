### Carro de Compras Kotlin Android Studio no cuenta con persistencia de datos.

### Carro de Compras Kotlin Android Studio Mejorado es el que cuenta con la persistencia de datos usando Shared Preferences.
